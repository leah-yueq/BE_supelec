#include "mainwindow.h"
#include <QApplication>
#include <iostream>
#include <sqlitedatabase.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    new SqliteDbase("Livres","BE","123456");
    MainWindow w;
    w.show(); 
    return a.exec();
}
