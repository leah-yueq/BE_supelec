#include <iostream>
#include <sqlitedatabase.h>
#include <QtSql/QtSql>

using namespace std;

SqliteDbase::SqliteDbase(QString dbname,QString username,QString pwd){

    if(QSqlDatabase::contains("qt_sql_default_connection")){
        database = QSqlDatabase::database("qt_sql_default_connection");
    }
    else{
        database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName(dbname);
        database.setUserName(username);
        database.setPassword(pwd);
    }
    newtable((QString*)"default");
}


void SqliteDbase::newtable(QString *tbname)
{
    QSqlQuery sql_query;
    QString create_sql = "create table "+*tbname+" (id int primary key, Auteurs QString, Titre QString,ISBN QString,Annee int)";
    sql_query.prepare(create_sql);
    if(!sql_query.exec())
    {
        qDebug() << "Error: Fail to create table." << sql_query.lastError();
    }
    else
    {
        this->tbnames->append(tbname);
        qDebug() << "Table created!";
    }
}

void SqliteDbase::deleteAll(QString *tbname)
{
    QSqlQuery sql_query;
    QString clear_sql = "delete from "+*tbname;
    sql_query.prepare(clear_sql);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "table cleared";
    }
}


void SqliteDbase::close()
{
    database.close();
}
