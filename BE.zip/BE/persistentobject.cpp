#include "persistentobject.h"
#include <QtSql/QtSql>
#include <iostream>
#include <qsqldatabase.h>

Persistentobject::Persistentobject(QString className, int id)
{
    *this->table=className;
    this->id=id;
}

void Persistentobject::addAttribute(PersistentAttribute * newattribute)
{
    this->attributes->append(newattribute);
}

int Persistentobject::save()
{
     QSqlDatabase db;
     QSqlQuery sql_query;
     db = QSqlDatabase::database("qt_sql_default_connection");
     if (!db.open())
     {
         qDebug() << "Error: Failed to connect database." << db.lastError();
         return 0;
     }
     else
     {
         QString insert_sql = "insert into "+*table+" values (?, ?, ?, ?, ?)";
         sql_query.prepare(insert_sql);
         sql_query.addBindValue(id);

         foreach(PersistentAttribute *tmp, *attributes)
         {
            // QString* c=(QString*)tmp->data;
             sql_query.addBindValue(QVariant::fromValue(tmp->data));
             // sql_query.addBindValue(QVariant::typeToName(tmp->type.Type)(*tmp->data));
         }

         if(!sql_query.exec())
         {
             return 0;
             qDebug() << sql_query.lastError();
         }
         else
         {
             return 1;
             qDebug() << "Saved!";
         }
     }
}
