#ifndef SQLITEDATABASE_H
#define SQLITEDATABASE_H

#include <qstring.h>
#include <QtSql/QtSql>

class SqliteDbase
{
public:

    SqliteDbase(QString dbname,QString username,QString pwd);
    void newtable(QString *);
    void deleteAll(QString *);
    void close();

private:
    QSqlDatabase database;
    QList<QString *> *tbnames;

};

#endif // SQLITEDATABASE_H
